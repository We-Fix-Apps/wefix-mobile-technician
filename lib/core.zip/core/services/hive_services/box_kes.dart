class BoxKeys {
  BoxKeys._();

  static String appBox = 'APP_BOX';
  // Auth
  static String enableAuth = 'ENABLE_AUTH';
  // Token Box
  static String usertoken = 'USER_TOKEN';
  // FCM Token Box
  static String fcmtoken = 'FCM_TOKEN';
  // User Box
  static String userData = 'USER_DATA';
}

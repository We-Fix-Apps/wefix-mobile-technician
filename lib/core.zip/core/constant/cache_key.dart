class CacheKey {
  CacheKey._();

  static const String lang = 'LANGUAGE_APP';
}

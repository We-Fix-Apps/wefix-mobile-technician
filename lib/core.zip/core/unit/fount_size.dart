abstract class AppFontSizes {
  static double xl5 = 48;
  static double xl4 = 36;
  static double xl3 = 30;
  static double xl2 = 24;
  static double xl = 20;
  static double lg = 18;
  static double md = 16;
  static double sm = 14;
  static double xs = 12;
}
